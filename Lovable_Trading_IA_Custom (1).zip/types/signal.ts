
export type MWDSignal = {
  pair: string;
  entry: number;
  stop_loss: number;
  take_profit: number;
  zone: string;
  reaction: string;
  commentaire: string;
  result?: "TP" | "SL" | "pending";
};
