
type AgentStatsProps = {
  agentName: string;
  level: "junior" | "intermédiaire" | "senior";
  rendement: string;
  winrate: string;
  drawdown: string;
  totalTrades: number;
  successfulTrades: number;
};

export const AgentStats = ({
  agentName,
  level,
  rendement,
  winrate,
  drawdown,
  totalTrades,
  successfulTrades
}: AgentStatsProps) => {
  return (
    <div className="p-4 rounded-xl shadow bg-white mb-4">
      <h2 className="text-xl font-bold mb-2">{agentName}</h2>
      <p>Niveau : {level}</p>
      <p>Rendement hebdo : {rendement}</p>
      <p>Taux de réussite : {winrate}</p>
      <p>Drawdown max : {drawdown}</p>
      <p>Trades totaux : {totalTrades}</p>
      <p>Trades gagnants : {successfulTrades}</p>
    </div>
  );
};
