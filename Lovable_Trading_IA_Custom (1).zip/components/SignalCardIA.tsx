
import { Card, CardContent } from "@/components/ui/card";

type SignalProps = {
  pair: string;
  entry: number;
  stop_loss: number;
  take_profit: number;
  zone: string;
  reaction: string;
  commentaire: string;
  result?: "TP" | "SL" | "pending";
};

export const SignalCardIA = ({ pair, entry, stop_loss, take_profit, zone, reaction, commentaire, result }: SignalProps) => {
  return (
    <Card className="rounded-2xl shadow-md p-4 mb-4">
      <CardContent>
        <h2 className="text-lg font-bold">{pair} – Signal IA</h2>
        <p><strong>Zone Weekly :</strong> {zone}</p>
        <p><strong>Réaction Daily :</strong> {reaction}</p>
        <p><strong>Entrée :</strong> {entry}</p>
        <p><strong>SL :</strong> {stop_loss}</p>
        <p><strong>TP :</strong> {take_profit}</p>
        <p><strong>Commentaire IA :</strong> {commentaire}</p>
        <p><strong>Résultat :</strong> {result || "En attente"}</p>
      </CardContent>
    </Card>
  );
};
