
# Intégration Trading IA – Lovable Frontend

## Fichiers inclus

- `SignalCardIA.tsx` → composant pour afficher les signaux IA MWD
- `AgentStats.tsx` → composant pour afficher les performances d’un agent IA
- `types/signal.ts` → types TypeScript pour structurer les signaux IA

## Où les placer

- Copie `SignalCardIA.tsx` et `AgentStats.tsx` dans `src/components/`
- Copie `signal.ts` dans `src/types/`
- Importe les composants dans `App.tsx` ou tout autre fichier de ton choix

## Exemple d’utilisation

```tsx
<SignalCardIA
  pair="EUR/USD"
  entry={1.0840}
  stop_loss={1.0810}
  take_profit={1.0890}
  zone="Weekly Resistance at 1.0840"
  reaction="Daily rejection with long upper wick"
  commentaire="Entrée sur rejet propre de la résistance weekly"
  result="TP"
/>

<AgentStats
  agentName="Expert EUR/USD"
  level="intermédiaire"
  rendement="+5.4%"
  winrate="67%"
  drawdown="2.1%"
  totalTrades={15}
  successfulTrades={10}
/>
```
